const CACHE_NAME = 'ruta-compartida-v1';
const APP_SHELL = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(()=>{})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  // Solo controlamos peticiones de nuestro propio origen (el "shell" de la
  // app: index.html, manifest, íconos). Todo lo demás — Chart.js por CDN,
  // el tipo de cambio, la sincronización con Isa — pasa directo a la red;
  // esas partes ya manejan sus propios fallos si no hay internet.
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request).then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      }).catch(() => cached);
      // Si ya lo teníamos en caché, lo servimos al instante (rápido y
      // funciona sin internet); si no, esperamos la red.
      return cached || fetchPromise;
    })
  );
});
